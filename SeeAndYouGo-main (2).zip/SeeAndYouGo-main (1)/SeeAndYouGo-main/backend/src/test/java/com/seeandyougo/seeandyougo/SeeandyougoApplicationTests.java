package com.seeandyougo.seeandyougo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeeandyougoApplicationTests {

	@Test
	void contextLoads() {
	}

}
