package com.seeandyougo.seeandyougo.skj.repository;

public class CapacityRepository {

}
