package com.seeandyougo.seeandyougo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeeandyougoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SeeandyougoApplication.class, args);
	}

}
