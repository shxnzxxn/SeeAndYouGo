module.exports = {
    babel: {
        presets: ["@emotion/babel-preset-css-prop"],
    },
};

